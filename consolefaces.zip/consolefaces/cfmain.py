# Creates Input
x = str(input("Enter a Command: "))

# Choice Library
if x == 'help':
    quit
    import os
    os.system('cmd /k "python3 cfboot.py"')
elif x == 'end':
    print("Thanks for Using ConsoleFaces! Come Back Soon <3")
    quit
elif x == 'lenny':
    print("""\
        Here You Are:
        ( ͡° ͜ʖ ͡°)
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py"')
elif x == 'shrug':
    print("""\
        Here You Are:
        ¯\_(ツ)_/¯
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py"')
elif x == 'money':
    print("""
        Here You Are:
        [̲̅$̲̅(̲̅5̲̅)̲̅$̲̅]
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py')
else:
    print("""\
        Invalid Option!
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py')