# Prints Start Message
print("""\
----- ConsoleFaces -----
Version 1.0.0
Developer: HenreeQT | HenreeQT#1273 on Discord
Faces Brought to You by: https://textfac.es
----------------------------------------------

--- Commands ---
help  | Displays This Prompt
end   | Exits ConsoleFaces
lenny | Prints Lenny Face on Console
shrug | Prints Shrug Face on Console
money | Prints $5 Face on Console
""")

# Creates Input
x = str(input("Enter a Command: "))

# Choice Library
if x == 'help':
    quit
    import os
    os.system('cmd /k "python3 cfboot.py"')
elif x == 'end':
    print("Thanks for Using ConsoleFaces! Come Back Soon <3")
    quit
elif x == 'lenny':
    print("""\
        Here You Are:
        ( ͡° ͜ʖ ͡°)
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py"')
elif x == 'shrug':
    print("""\
        Here You Are:
        ¯\_(ツ)_/¯
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py"')
elif x == 'money':
    print("""
        Here You Are:
        [̲̅$̲̅(̲̅5̲̅)̲̅$̲̅]
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py')
else:
    print("""\
        Invalid Option!
        Run 'help' For Commands!
    """)
    quit
    import os
    os.system('cmd /k "python3 cfmain.py')